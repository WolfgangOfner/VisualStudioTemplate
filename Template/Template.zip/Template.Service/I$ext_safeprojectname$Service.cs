﻿using System.Collections.Generic;

namespace $ext_safeprojectname$.Service
{
    public interface I$ext_safeprojectname$Service
    {
        List<string> GetAll();
    }
}