﻿using System.Collections.Generic;

namespace $ext_safeprojectname$.Data
{
    public interface I$ext_safeprojectname$Repository
    {
        List<string> GetAll();
    }
}